#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
echo "[V9.1] 正在更新源码..."
cp -f app/src/main/java/com/openai/uvcard/EditorView.java "$ROOT/app/src/main/java/com/openai/uvcard/EditorView.java"
cp -f app/src/main/java/com/openai/uvcard/MainActivity.java "$ROOT/app/src/main/java/com/openai/uvcard/MainActivity.java"
cp -f app/build.gradle "$ROOT/app/build.gradle"
mkdir -p "$ROOT/.github/workflows"
cp -f .github/workflows/build-apk.yml "$ROOT/.github/workflows/build-apk.yml"
cp -f README.md "$ROOT/README.md"

git add app/src/main/java/com/openai/uvcard/EditorView.java \
        app/src/main/java/com/openai/uvcard/MainActivity.java \
        app/build.gradle .github/workflows/build-apk.yml README.md
if git diff --cached --quiet; then
  echo "[V9.1] 没有检测到需要提交的变化。"
else
  git commit -m "Upgrade to V9.1 portrait auto tone and crisper edges"
  git push
fi
echo "[V9.1] 完成：已推送到 GitHub，Actions 将自动生成 UVCard-V9.1-debug-apk。"
